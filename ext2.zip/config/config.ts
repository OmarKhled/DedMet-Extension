export default {
  domain: "https://dedmet.app",
};
