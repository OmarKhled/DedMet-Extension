///<reference types="chrome"/>
declare module "*.scss";
declare module "*.ejs";
